import os
import re
import tempfile
import pathlib
import pythoncom                         # COM 初始化库
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import win32com.client as win32
from openai import OpenAI
import streamlit as st
from streamlit_mic_recorder import mic_recorder
import speech_recognition as sr
from st_aggrid import AgGrid, GridOptionsBuilder, JsCode

# ---------- 全局显示与模型配置 ----------
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

client = OpenAI(
    api_key="sk-f02cc62ca6a14c40a1d80d06e6476eb0",
    base_url="https://api.deepseek.com"
)
MODEL_NAME = "deepseek-chat"

# ---------- Session State 初始化 ----------
if 'df' not in st.session_state:
    st.session_state.df = None
if 'excel_path' not in st.session_state:
    st.session_state.excel_path = None
if 'modified_cells' not in st.session_state:
    st.session_state.modified_cells = {}
if 'outputs' not in st.session_state:
    st.session_state.outputs = []
if 'figures' not in st.session_state:
    st.session_state.figures = []
if 'pending_code' not in st.session_state:
    st.session_state.pending_code = None
if 'messages' not in st.session_state:
    st.session_state.messages = [{
        "role": "system",
        "content": (
            "你是一个 Excel & DataFrame 智能助手。当用户提出与数据或 Excel "
            "相关的指令时，先用一句中文简要说明，然后输出可执行的 Python 代码块（用 ```python 包裹）。\n"
            "可用环境变量：excel_path (str)、df (pd.DataFrame)。\n"
            "已导入库：pandas as pd, numpy as np, matplotlib.pyplot as plt,\n"
            "pythoncom, win32com.client as win32, os, re, pathlib, streamlit as st。\n"
            "切勿重新创建 df！若需绘图，请把 Figure 对象放入 figs 列表，如 figs=[fig]。\n"
            "# … 创建chart可以参考这个代码避免category的问题。 …"
            "ax = chart.Axes(constants.xlCategory)   # 拿到分类（X）轴"
            "ax.HasTitle = True                     # 打开标题显示"
            "ax.AxisTitle.Text = '数学成绩分布'      # 通过 AxisTitle.Text 来写文字"
        )
    }]

# ---------- 把 DataFrame & Excel 信息写入上下文 ----------
def append_df_schema_msg():
    # 删除旧的提示
    st.session_state.messages = [
        m for m in st.session_state.messages
        if not (m["role"]=="system" and m["content"].startswith("DataFrame 信息"))
    ]
    if st.session_state.df is None:
        return
    schema = st.session_state.df.drop(columns='学生ID', errors='ignore') \
             .dtypes.astype(str).to_dict()
    n_rows = len(st.session_state.df)
    st.session_state.messages.insert(1, {
        "role":"system",
        "content": f"DataFrame 信息：行数={n_rows}，列名与类型={schema}。"
    })
    if st.session_state.excel_path:
        st.session_state.messages.insert(2, {
            "role":"system",
            "content": f"当前 Excel 文件路径：{st.session_state.excel_path}"
        })

# ---------- 自定义 AgGrid 样式 & 显示函数 ----------
cellstyle_jscode = JsCode('''
function(params) {
    const cellId = params.colDef.field + '-' + params.node.id;
    if (window.modifiedCells && window.modifiedCells.includes(cellId)) {
        return {'backgroundColor':'#FFF3CD','border':'2px solid #FFC107'};
    }
}
''')

def show_aggrid(df):
    gb = GridOptionsBuilder.from_dataframe(df)
    gb.configure_grid_options(domLayout='normal')
    gb.configure_default_column(
        resizable=True, minWidth=120, flex=1,
        editable=True, cellStyle=cellstyle_jscode,
        filter=True, sortable=True
    )
    opts = gb.build()
    opts['getRowId'] = JsCode("function(p){return p.data['学生ID'];}")
    return AgGrid(
        df, gridOptions=opts, height=400, width='100%',
        data_return_mode='FILTERED_AND_SORTED',
        update_mode='MODEL_CHANGED', key='grid',
        allow_unsafe_jscode=True, fit_columns_on_grid_load=True
    )

# ---------- 页面布局 ----------
st.title("📊 智能成绩分析系统 v3")
left_col, right_col = st.columns([4, 5])

# —— 重放缓存的图表与普通输出 ——
if st.session_state.figures:
    for fig in st.session_state.figures:
        st.pyplot(fig)
    st.session_state.figures.clear()

for fn, args, kwargs in st.session_state.outputs:
    getattr(st, fn)(*args, **kwargs)
st.session_state.outputs.clear()

# ===== 左侧：上传 & DataFrame 可视化 =====
with left_col:
    uploaded_file = st.file_uploader("上传 Excel 文件", type=['xlsx','xls'])
    if uploaded_file:
        # 保存到临时文件
        suffix = pathlib.Path(uploaded_file.name).suffix or ".xlsx"
        tmp_path = tempfile.NamedTemporaryFile(delete=False, suffix=suffix).name
        with open(tmp_path, "wb") as f:
            f.write(uploaded_file.getbuffer())
        st.session_state.excel_path = tmp_path

        # 读取到 df，并加学生ID
        st.session_state.df = (
            pd.read_excel(tmp_path)
              .assign(学生ID=lambda x: np.arange(len(x)))
        )
        grade_cols = st.session_state.df.columns.drop('学生ID')
        st.session_state.df[grade_cols] = st.session_state.df[grade_cols].apply(
            pd.to_numeric, errors='coerce'
)
    if st.session_state.df is not None:
        st.subheader("原始数据")
        grid_resp = show_aggrid(st.session_state.df)
        if not grid_resp['data'].equals(st.session_state.df):
            st.session_state.df = grid_resp['data']
            st.rerun()

        # 本地 matplotlib 饼图示例
        selected = st.selectbox(
            "选择分析科目",
            st.session_state.df.columns.drop('学生ID'), index=0
        )
        c1, c2 = st.columns(2)
        with c1:
            if st.button("计算平均值"):
        # 取出选中科目的数值列，跳过 NaN
                avg = st.session_state.df[selected].mean(skipna=True)
                st.success(f"📈 {selected} 平均值：{avg:.2f}")
        with c2:
            if st.button("计算中位数"):
                med = st.session_state.df[selected].median(skipna=True)
                st.success(f"🔢 {selected} 中位数：{med:.2f}")
        bins_in = st.text_input("分数段设置（逗号分隔）", "0,60,70,80,90,100")
        if st.button("在网页端生成 matplotlib 饼图"):
            try:
                bins = list(map(int, bins_in.split(',')))
                fig, ax = plt.subplots()
                data = pd.to_numeric(st.session_state.df[selected], errors='coerce').dropna()
                cats = pd.cut(data, bins=bins, include_lowest=True, right=False)
                cnt = cats.value_counts().sort_index()
                labels = [f"{int(i.left)}-{int(i.right)}" for i in cnt.index]
                ax.pie(cnt, labels=labels, autopct="%1.1f%%")
                ax.set_title(f"{selected} 成绩分布")
                st.pyplot(fig)
            except Exception as e:
                st.error(f"绘图错误: {e}")

# ===== 右侧：智能助手 & 代码执行 =====
with right_col:
    st.subheader("智能助手")
    # 历史消息
    for m in st.session_state.messages[1:]:
        with st.chat_message(m["role"]):
            st.markdown(m["content"])

    # 语音输入
    audio = mic_recorder("🎤 语音输入", "⏹️ 停止录音", key="recorder")
    if audio and audio['bytes']:
        try:
            aud = sr.AudioData(audio['bytes'],
                               audio['sample_rate'],
                               audio['sample_width'])
            txt = sr.Recognizer().recognize_google(aud,
                                                   language="zh-CN")
            st.session_state.last_voice_input = txt
            st.rerun()
        except Exception as e:
            st.error(f"语音识别错误：{e}")

    # 文本输入表单
    
    with st.form("chat_input"):
        user_text = st.text_input(
            "输入指令",
            value=st.session_state.get('last_voice_input',''),
            key="input_text"
        )
        send = st.form_submit_button("发送")
    bins_in = st.text_input(
    label="分数段设置（逗号分隔）",
    value="0,60,70,80,90,100",
    key="bins_in_input"     # ← 唯一的 key
)
    if send and user_text.strip():
        st.session_state.messages.append(
            {"role":"user","content":user_text}
        )
        append_df_schema_msg()

        try:
            rsp = client.chat.completions.create(
                model=MODEL_NAME,
                messages=st.session_state.messages,
                temperature=0.3,
                max_tokens=1024
            )
            ai_text = rsp.choices[0].message.content

            # 如果包含 Python 代码块，则拆分执行
            if "```python" in ai_text:
                prefix, code_block = ai_text.split("```python",1)
                code = code_block.split("```")[0].strip()
                if prefix.strip():
                    st.session_state.messages.append({
                        "role":"assistant",
                        "content":prefix.strip()
                    })

                # 打补丁，缓存 write/dataframe/table
                import types
                def _wrap(fn_name):
                    real = getattr(st, fn_name)
                    def _inner(*args, **kwargs):
                        st.session_state.outputs.append((fn_name,args,kwargs))
                        return real(*args, **kwargs)
                    return _inner

                patched_st = types.SimpleNamespace(**{
                    n:getattr(st,n) for n in dir(st)
                    if not n.startswith('_')
                })
                for _fn in ('write','dataframe','table'):
                    setattr(patched_st, _fn, _wrap(_fn))

                # 在本地初始化 COM
                pythoncom.CoInitialize()

                exec_env = {
                    'df'         : st.session_state.df.drop(columns='学生ID'),
                    'pd'         : pd,
                    'np'         : np,
                    'plt'        : plt,
                    'st'         : patched_st,
                    'excel_path' : st.session_state.excel_path,
                    'win32'      : win32,
                    'pythoncom'  : pythoncom,
                    'os'         : os,
                    're'         : re,
                    'pathlib'    : pathlib,
                    'bins_in'    : bins_in 
                }

                # 执行 AI 生成的代码
                exec(code, exec_env)

                # 反初始化 COM
                pythoncom.CoUninitialize()

                # 如果 df 被修改，写回
                if 'df' in exec_env:
                    new_df = exec_env['df'].reset_index(drop=True)
                    new_df['学生ID'] = st.session_state.df['学生ID']
                    st.session_state.df = new_df

                # 缓存所有 matplotlib 图
                figs = exec_env.get('figs') or [
                    plt.figure(n) for n in plt.get_fignums()
                ]
                if figs:
                    st.session_state.figures = figs
                    plt.close('all')

                # 确认消息
                st.session_state.messages.append({
                    "role":"assistant",
                    "content":"✅ 代码执行完毕。"
                })
                st.rerun()

            else:
                # 仅文本回复
                st.session_state.messages.append({
                    "role":"assistant","content":ai_text
                })
                st.rerun()

        except Exception as e:
            st.error(f"处理失败：{e}")
            st.session_state.messages.append({
                "role":"assistant",
                "content":f"执行错误：{e}"
            })
            st.rerun()

# ---------- 文件下载 ----------
if st.session_state.df is not None:
    csv = st.session_state.df.drop(columns='学生ID') \
           .to_csv(index=False).encode()
    st.download_button("下载数据为 CSV",
                       csv, "analysis_result.csv","text/csv")
