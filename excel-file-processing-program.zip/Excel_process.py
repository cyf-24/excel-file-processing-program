import pandas as pd
import matplotlib.pyplot as plt
import requests
import re
import os
import time
from datetime import datetime

# --------------------------
# 配置区域（用户需修改部分）
# --------------------------
DEEPSEEK_API_KEY = "sk-6420e2eb48324eb3a783bc09c8b66aa5"  # <- 请在此处填写密钥
API_URL = "https://api.deepseek.com/v1/chat/completions"
EXCEL_FILE = "scores.xlsx"  # 输入文件路径
OUTPUT_REPORT = "analysis_report.md"  # 输出报告路径

# --------------------------
# 初始化配置
# --------------------------
# 配置中文字体（修复中文乱码问题）
plt.rcParams['font.sans-serif'] = ['SimHei']  # Windows系统字体
plt.rcParams['axes.unicode_minus'] = False  # 正确显示负号


# --------------------------
# 日志记录模块
# --------------------------
class Logger:
    @staticmethod
    def log_step(message):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"[{timestamp}] ▶ {message}")

    @staticmethod
    def log_substep(message):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"  ├─ {message}")

    @staticmethod
    def log_warning(message):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"  ⚠️ [{timestamp}] WARNING: {message}")

    @staticmethod
    def log_success(message):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"  ✅ [{timestamp}] SUCCESS: {message}")


# --------------------------
# 大模型交互模块
# --------------------------
def parse_with_deepseek(query):
    Logger.log_step("开始解析用户查询")
    Logger.log_substep(f"原始查询内容: '{query}'")

    headers = {
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        "Content-Type": "application/json"
    }

    system_prompt = """请从用户输入中提取以下信息：
    - 科目列表（从数学、语文、英语、物理、化学、生物、历史、地理、政治中选择）
    - 分数段规则（如未指定则默认为[0,60,80,100]）
    - 图表类型（饼图/柱状图/雷达图等）

    按此格式返回：
    【科目】数学,物理
    【分段】0,70,90,100
    【图表】柱状图"""

    data = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": query}
        ],
        "temperature": 0.1
    }

    try:
        Logger.log_substep("发送API请求到DeepSeek...")
        start_time = time.time()
        response = requests.post(API_URL, headers=headers, json=data)
        latency = time.time() - start_time

        if response.status_code != 200:
            Logger.log_warning(f"API请求失败 (HTTP {response.status_code})")
            raise Exception(f"API Error: {response.text}")

        Logger.log_success(f"收到API响应 (耗时 {latency:.2f}s)")
        return response.json()['choices'][0]['message']['content']

    except requests.exceptions.RequestException as e:
        Logger.log_warning(f"网络连接异常: {str(e)}")
        raise


# --------------------------
# 参数解析模块
# --------------------------
def parse_response(response_text):
    Logger.log_step("解析大模型返回结果")
    Logger.log_substep(f"原始响应文本:\n{'-' * 30}\n{response_text}\n{'-' * 30}")

    try:
        # 科目解析
        subject_match = re.search(r"【科目】(.+)", response_text)
        subjects = subject_match.group(1).split(',')
        Logger.log_substep(f"解析到科目: {subjects}")

        # 分数段解析
        bins_match = re.search(r"【分段】(.+)", response_text)
        bins = list(map(int, bins_match.group(1).split(',')))
        Logger.log_substep(f"解析到分数段: {bins}")

        # 图表类型解析
        chart_match = re.search(r"【图表】(.+)", response_text)
        chart_type = chart_match.group(1).strip()
        Logger.log_substep(f"解析到图表类型: {chart_type}")

        return subjects, bins, chart_type

    except AttributeError as e:
        Logger.log_warning("响应格式解析失败")
        raise ValueError("大模型返回格式不符合预期，请检查提示词设置")


# --------------------------
# 可视化生成模块
# --------------------------
def generate_visualization(df, subjects, bins, chart_type):
    Logger.log_step("生成可视化图表")

    images = []
    for subject in subjects:
        Logger.log_substep(f"正在处理科目: {subject}")

        if subject not in df.columns:
            Logger.log_warning(f"无效科目 '{subject}'，跳过处理")
            continue

        # 分数段计算
        Logger.log_substep("计算分数段分布...")
        labels = [f"{bins[i]}-{bins[i + 1]}" for i in range(len(bins) - 1)]
        try:
            data = pd.cut(df[subject], bins=bins, labels=labels)
            counts = data.value_counts(normalize=True).sort_index()
        except Exception as e:
            Logger.log_warning(f"分数段计算失败: {str(e)}")
            continue

        # 图表生成
        plt.figure(figsize=(10, 6), dpi=150)
        try:
            if "饼" in chart_type:
                Logger.log_substep("生成饼图...")
                plt.pie(counts, labels=counts.index, autopct='%1.1f%%')
                plt.title(f'{subject}分数段占比', pad=20)
            elif "柱" in chart_type:
                Logger.log_substep("生成柱状图...")
                plt.bar(counts.index, counts.values)
                plt.title(f'{subject}分数段人数分布')
                plt.ylabel('占比')
                plt.xticks(rotation=45)
        except Exception as e:
            Logger.log_warning(f"图表生成失败: {str(e)}")
            plt.close()
            continue

        # 保存图片
        try:
            filename = f"{subject}_analysis.png"
            plt.savefig(filename, bbox_inches='tight', pad_inches=0.5)
            plt.close()
            Logger.log_success(f"保存图表到 {filename}")
            images.append(filename)
        except Exception as e:
            Logger.log_warning(f"图表保存失败: {str(e)}")
            plt.close()

    return images


# --------------------------
# 报告生成模块
# --------------------------
def generate_report(df, subjects, bins):
    Logger.log_step("生成分析报告")

    report = ["# 成绩分析报告\n"]

    for subject in subjects:
        Logger.log_substep(f"生成 {subject} 科目分析...")
        if subject not in df.columns:
            continue

        stats = df[subject].describe()
        report.extend([
            f"## {subject}科目分析",
            f"- **平均分**: {stats['mean']:.1f}",
            f"- **标准差**: {stats['std']:.1f}",
            f"- **最高分**: {stats['max']}",
            f"- **最低分**: {stats['min']}",
            f"- **分数段划分**: {bins}",
            "\n"
        ])

    Logger.log_success("报告内容生成完成")
    return "\n".join(report)


# --------------------------
# 主程序
# --------------------------
def main(excel_path):
    try:
        # 初始化
        Logger.log_step(f"🔍 开始分析流程")
        Logger.log_substep(f"输入文件: {os.path.abspath(excel_path)}")

        # 读取数据
        Logger.log_step("读取Excel文件")
        try:
            df = pd.read_excel(excel_path)
            Logger.log_success(f"成功读取 {len(df)} 条记录")
        except Exception as e:
            Logger.log_warning(f"文件读取失败: {str(e)}")
            raise

        # 用户输入
        query = input("请输入分析需求（例如：对比数学和语文成绩，分三个分数段用饼图显示）: ")
        Logger.log_substep(f"用户需求: '{query}'")

        # 大模型解析
        response_text = parse_with_deepseek(query)
        subjects, bins, chart_type = parse_response(response_text)
        Logger.log_substep(f"最终参数: 科目={subjects}, 分段={bins}, 图表类型={chart_type}")

        # 生成可视化
        images = generate_visualization(df, subjects, bins, chart_type)

        # 生成报告
        report_content = generate_report(df, subjects, bins)

        # 保存报告
        Logger.log_step(f"保存分析报告到 {OUTPUT_REPORT}")
        try:
            with open(OUTPUT_REPORT, "w", encoding="utf-8") as f:
                f.write(report_content)
                for img in images:
                    f.write(f"\n![{img}]({img})")
            Logger.log_success("报告保存成功")
        except Exception as e:
            Logger.log_warning(f"报告保存失败: {str(e)}")
            raise

    except Exception as e:
        Logger.log_warning(f"流程异常终止: {str(e)}")
    finally:
        Logger.log_step("🏁 分析流程结束")


# --------------------------
# 执行入口
# --------------------------
if __name__ == "__main__":
    main(EXCEL_FILE)