import os
import pandas as pd
import matplotlib.pyplot as plt
from openai import OpenAI
import streamlit as st
from streamlit_mic_recorder import mic_recorder
import speech_recognition as sr
from st_aggrid import AgGrid, GridOptionsBuilder, JsCode
import numpy as np

# ---------- 全局显示与模型配置 ----------
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

client = OpenAI(
    api_key="sk-f02cc62ca6a14c40a1d80d06e6476eb0",
    base_url="https://api.deepseek.com"
)
MODEL_NAME = "deepseek-chat"

# ---------- Session State 初始化 ----------
if 'df' not in st.session_state:
    st.session_state.df = None
if 'modified_cells' not in st.session_state:
    st.session_state.modified_cells = {}
if 'messages' not in st.session_state:
    st.session_state.messages = [{
        "role": "system",
        "content": (
            "你是一个智能表格助手。当用户提出与 DataFrame 操作相关的命令时，"
            "请先用自然语言简要回答，然后输出可在 Python 中执行的代码块（必须用 ```python 包裹）"
            " 若与 DataFrame 无关，则正常闲聊即可。\n"
            "你的输出会被显示到streamlit中，请你自动引入streamlit库，并尽可能使用st.write()函数"
            "代码会作用于名为 df 的 pandas DataFrame，切勿重新创建 df！\n"
            "如果需要绘图，请把 matplotlib.figure.Figure 对象放到名为 figs 的列表里，例如：\n"
            "```python\nfig, ax = plt.subplots(); ...; figs = [fig]\n```"
        )
    }]
if 'outputs' not in st.session_state:
    st.session_state.outputs = []
if 'figures' not in st.session_state:
    st.session_state.figures = []
# ---------- 把 DataFrame 结构写入对话上下文 ----------
def append_df_schema_msg():
    st.session_state.messages = [
        m for m in st.session_state.messages
        if not (m["role"] == "system" and m["content"].startswith("DataFrame 信息：行数"))
    ]
    if st.session_state.df is None:
        return
    schema = (
        st.session_state.df.drop(columns='学生ID', errors='ignore')
        .dtypes.astype(str)
        .to_dict()
    )
    n_rows = len(st.session_state.df)
    st.session_state.messages.insert(1, {
        "role": "system",
        "content": f"DataFrame 信息：行数={n_rows}，列名与类型={schema}。"
    })

# ---------- 自定义 AgGrid 单元格样式 ----------
cellstyle_jscode = JsCode('''
function(params) {
    const cellId = params.colDef.field + '-' + params.node.id;
    if (window.modifiedCells && window.modifiedCells.includes(cellId)) {
        return {
            'backgroundColor': '#FFF3CD',
            'border': '2px solid #FFC107'
        }
    }
}
''')

def show_aggrid(df):
    gb = GridOptionsBuilder.from_dataframe(df)
    gb.configure_grid_options(domLayout='normal')  # 横向滚动
    gb.configure_default_column(
        resizable=True, minWidth=120, flex=1,        # 自适应列宽
        editable=True, cellStyle=cellstyle_jscode,
        filter=True, sortable=True
    )
    opts = gb.build()
    opts['getRowId'] = JsCode("function(p){return p.data['学生ID'];}")

    return AgGrid(
        df,
        gridOptions=opts,
        height=400,
        width='100%',
        data_return_mode='FILTERED_AND_SORTED',
        update_mode='MODEL_CHANGED',
        key='grid',
        allow_unsafe_jscode=True,
        fit_columns_on_grid_load=True
    )

# ---------- 页面布局 ----------
st.title("📊 智能成绩分析系统 v3")
left_col, right_col = st.columns([4, 5])
if st.session_state.figures:
    for fig in st.session_state.figures:
        st.pyplot(fig)
    st.session_state.figures.clear()
# === PATCH 2: 回放缓存的 write/table/dataframe 输出 ===
for fn, args, kwargs in st.session_state.outputs:
    getattr(st, fn)(*args, **kwargs)
st.session_state.outputs.clear()

# ===== 左侧：数据与可视化 =====
with left_col:
    uploaded_file = st.file_uploader("上传 Excel 文件", type='xlsx')
    if uploaded_file:
        st.session_state.df = (
            pd.read_excel(uploaded_file)
            .assign(学生ID=lambda x: np.arange(len(x)))
        )

    if st.session_state.df is not None:
        st.subheader("原始数据（黄色单元格 = 修改过）")
        grid_response = show_aggrid(st.session_state.df)
        if not grid_response['data'].equals(st.session_state.df):
            st.session_state.df = grid_response['data']
            st.rerun()

        # 简易饼图按钮（示例）
        selected_subject = st.selectbox(
            "选择分析科目",
            st.session_state.df.columns.drop('学生ID'),
            index=0
        )
        bins_input = st.text_input("分数段设置（逗号分隔）", value="0,60,70,80,90,100")
        if st.button("生成成绩分布饼图"):
            try:
                bins = list(map(int, bins_input.split(',')))
                fig, ax = plt.subplots()
                data = st.session_state.df[selected_subject].dropna()
                cats = pd.cut(data, bins=bins)
                cnt = cats.value_counts().sort_index()
                labels = [f"{int(i.left)}-{int(i.right)}" for i in cnt.index]
                ax.pie(cnt, labels=labels, autopct="%1.1f%%")
                ax.set_title(f"{selected_subject} 成绩分布")
                st.pyplot(fig)
            except Exception as e:
                st.error(f"绘图错误: {e}")

# ===== 右侧：聊天与语音 =====
with right_col:
    st.subheader("智能助手")

    # 显示历史对话
    for m in st.session_state.messages[1:]:
        with st.chat_message(m["role"]):
            st.markdown(m["content"])

    # 语音输入
    audio = mic_recorder("🎤 语音输入", "⏹️ 停止录音", key="recorder")
    if audio and audio['bytes']:
        try:
            aud = sr.AudioData(audio['bytes'], audio['sample_rate'], audio['sample_width'])
            text = sr.Recognizer().recognize_google(aud, language="zh-CN")
            st.session_state.last_voice_input = text
            st.rerun()
        except Exception as e:
            st.error(f"语音识别错误：{e}")

    # 文本输入
    with st.form("chat_input"):
        user_text = st.text_input(
            "输入指令",
            value=st.session_state.get('last_voice_input', ''),
            key="input_text"
        )
        send = st.form_submit_button("发送")

    if send and user_text.strip():
        st.session_state.messages.append({"role": "user", "content": user_text})
        append_df_schema_msg()

        try:
            rsp = client.chat.completions.create(
                model=MODEL_NAME,
                messages=st.session_state.messages,
                temperature=0.3,
                max_tokens=1024
            )
            ai_text = rsp.choices[0].message.content

            # -------- 执行代码块 --------
            if "```python" in ai_text:
                prefix,code=ai_text.split("```python",1)
                code = ai_text.split("```python")[1].split("```")[0].strip()
                if prefix.strip():
                    st.session_state.messages.append({"role": "assistant", "content": prefix.strip()})
                import types
                def _wrap(fn_name):
                    real_fn = getattr(st, fn_name)
                    def _inner(*args, **kwargs):
                        st.session_state.outputs.append((fn_name, args, kwargs))
                        return real_fn(*args, **kwargs)      # 当轮立即显示
                    return _inner

                patched_st = types.SimpleNamespace(**{n: getattr(st, n) for n in dir(st) if not n.startswith('_')})
                for _n in ('write', 'dataframe', 'table'):
                    setattr(patched_st, _n, _wrap(_n))

                exec_env = {
                    'df': st.session_state.df.drop(columns='学生ID'),
                    'pd': pd, 'np': np, 'plt': plt,
                    'st': patched_st                 # ← 用打补丁后的 st
                }
 
                exec(code, exec_env)

                # 更新 df（如果修改了）
                if 'df' in exec_env:
                    new_df = exec_env['df'].reset_index(drop=True)
                    new_df['学生ID'] = st.session_state.df['学生ID']
                    st.session_state.df = new_df

                # 展示图表
                # -------- 展示图表 --------
                shown_figs = []

                if 'figs' in exec_env and isinstance(exec_env['figs'], list):
                    shown_figs = exec_env['figs']
                elif plt.get_fignums():
                    shown_figs = [plt.figure(num) for num in plt.get_fignums()]

                if shown_figs:
    # 把图存进 session_state，稍后统一展示
                    st.session_state.figures = shown_figs
                    plt.close('all')

                st.session_state.messages.append({
                 "role": "assistant",
                "content": f"已执行代码：\n```python\n{code}\n```"
                })
                st.rerun()          # 让新 DF + 图表立即生效


            # -------- 普通文本回复 --------
            else:
                st.session_state.messages.append({"role": "assistant", "content": ai_text})
                st.rerun()

        except Exception as e:
            st.error(f"处理失败：{e}")
            st.session_state.messages.append({
                "role": "assistant",
                "content": f"执行错误：{e}"
            })
            st.rerun()

# ---------- 文件下载 ----------
if st.session_state.df is not None:
    csv = st.session_state.df.drop(columns='学生ID').to_csv(index=False).encode()
    st.download_button("下载数据为 CSV", csv, "analysis_result.csv", "text/csv")
